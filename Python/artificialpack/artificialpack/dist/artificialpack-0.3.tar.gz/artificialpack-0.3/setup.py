from setuptools import setup, find_packages
setup(name="artificialpack",
version="0.3",
description="This package returns a number that you gave...",
Long_description="Long is short",
author="Pulkit",
packages=[r'D:\code docs\Python\artificialpack\artificialpack'],
install_requires=[])#add a module if you used in the init